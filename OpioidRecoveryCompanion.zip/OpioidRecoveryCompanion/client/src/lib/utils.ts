import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatTimeAgo(date: Date): string {
  const now = new Date();
  const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);
  
  if (diffInSeconds < 60) {
    return "Just now";
  } else if (diffInSeconds < 3600) {
    const minutes = Math.floor(diffInSeconds / 60);
    return `${minutes}m ago`;
  } else if (diffInSeconds < 86400) {
    const hours = Math.floor(diffInSeconds / 3600);
    return `${hours}h ago`;
  } else {
    const days = Math.floor(diffInSeconds / 86400);
    return `${days}d ago`;
  }
}

export function getMoodColor(mood: number): string {
  if (mood <= 3) return "text-red-500";
  if (mood <= 5) return "text-orange-500";
  if (mood <= 7) return "text-yellow-500";
  return "text-green-500";
}

export function getCravingColor(craving: string): string {
  switch (craving) {
    case "none": return "text-green-500";
    case "mild": return "text-yellow-500";
    case "moderate": return "text-orange-500";
    case "strong": return "text-red-500";
    default: return "text-gray-500";
  }
}

import { useState, useMemo } from "react";
import { Heart, Brain, Pill, Users, Lightbulb, Leaf, Phone, Calendar, Award, Target } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery } from "@tanstack/react-query";
import QuickCheckInModal from "@/components/QuickCheckInModal";
import ProgressChart from "@/components/ProgressChart";
import type { User, MoodLog, Resource, Professional } from "@shared/schema";
import { getMoodColor, getCravingColor, formatTimeAgo } from "@/lib/utils";

export default function Dashboard() {
  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState(false);
  const userId = localStorage.getItem("userId");

  const { data: user } = useQuery<User>({
    queryKey: ["/api/user", userId],
    enabled: !!userId,
  });

  const { data: moodLogs = [] } = useQuery<MoodLog[]>({
    queryKey: ["/api/mood-logs", userId],
    enabled: !!userId,
  });

  const { data: resources = [] } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  const { data: professionals = [] } = useQuery<Professional[]>({
    queryKey: ["/api/professionals"],
  });

  // Calculate days sober from recovery start date
  const daysSober = useMemo(() => {
    if (!user?.recoveryStartDate) return 0;
    const startDate = new Date(user.recoveryStartDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - startDate.getTime());
    return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  }, [user?.recoveryStartDate]);

  // Get addiction-specific tips based on user's addiction types
  const personalizedTips = useMemo(() => {
    if (!user?.addictionTypes || user.addictionTypes.length === 0) {
      return [
        "Take recovery one day at a time",
        "Build a strong support network", 
        "Practice self-care and stress management"
      ];
    }

    const tips: { [key: string]: string[] } = {
      alcohol: [
        "Stay hydrated with water throughout the day",
        "Avoid places and people that trigger drinking urges",
        "Consider attending AA meetings for support"
      ],
      opioids: [
        "Take prescribed medications exactly as directed",
        "Carry naloxone (Narcan) if recommended by your doctor",
        "Build a strong support network of sober friends"
      ],
      cocaine: [
        "Engage in regular physical exercise to manage cravings",
        "Practice stress management techniques like meditation",
        "Avoid cash and situations that trigger use"
      ],
      cannabis: [
        "Find new hobbies to replace smoking time",
        "Use CBD products if recommended by your doctor",
        "Focus on improving sleep hygiene"
      ],
      nicotine: [
        "Use nicotine replacement therapy if prescribed",
        "Avoid smoking triggers like alcohol or coffee",
        "Keep your hands busy with stress balls or fidgets"
      ],
      methamphetamine: [
        "Get plenty of sleep to help brain recovery",
        "Eat nutritious meals to restore physical health",
        "Engage in positive social activities"
      ],
      benzodiazepines: [
        "Never stop taking prescribed benzos without medical supervision",
        "Practice relaxation techniques for anxiety",
        "Attend therapy sessions regularly"
      ]
    };

    const personalizedTips: string[] = [];
    user.addictionTypes.forEach((type: string) => {
      if (tips[type]) {
        personalizedTips.push(...tips[type]);
      }
    });

    return personalizedTips.length > 0 ? personalizedTips.slice(0, 3) : [
      "Take recovery one day at a time",
      "Build a strong support network",
      "Practice self-care and stress management"
    ];
  }, [user?.addictionTypes]);

  const latestMoodLog = moodLogs[0];
  const avgMood = moodLogs.length > 0 
    ? (moodLogs.reduce((sum, log) => sum + log.mood, 0) / moodLogs.length).toFixed(1)
    : "N/A";

  const managedCravings = moodLogs.length > 0
    ? Math.round((moodLogs.filter(log => log.cravingLevel === "none" || log.cravingLevel === "mild").length / moodLogs.length) * 100)
    : 0;

  const featuredResources = resources.slice(0, 2);
  const featuredProfessionals = professionals.slice(0, 3);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      {/* Welcome Section */}
      <div className="mb-8">
        <div className="bg-gradient-to-r from-primary-50 to-secondary-50 rounded-2xl p-6 border border-gray-200">
          <h2 className="text-2xl font-semibold text-gray-900 mb-2">
            Welcome back, {user?.username || "User"}
          </h2>
          <p className="text-gray-600 mb-4">
            Today marks <span className="font-semibold text-primary-600">{daysSober} days</span> of your recovery journey.
          </p>
          {user?.addictionTypes && user.addictionTypes.length > 0 && (
            <div className="flex flex-wrap gap-2 mb-4">
              {user.addictionTypes.map((type) => (
                <Badge key={type} variant="secondary" className="bg-primary-100 text-primary-700">
                  {type.charAt(0).toUpperCase() + type.slice(1)} recovery
                </Badge>
              ))}
            </div>
          )}
          <div className="flex gap-3">
            <Button 
              onClick={() => setIsCheckInModalOpen(true)}
              className="bg-primary-500 hover:bg-primary-600 text-white"
            >
              Quick Check-in
            </Button>
            <Button variant="outline" className="border-primary-200 text-primary-600 hover:bg-gray-50">
              View Progress
            </Button>
          </div>
        </div>
      </div>

      {/* Quick Actions Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Mood Tracking Card */}
        <Card className="hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-primary-50 rounded-lg flex items-center justify-center">
                <Heart className="text-primary-500 w-6 h-6" />
              </div>
              <span className="text-sm text-gray-500">Today</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Mood Check</h3>
            <p className="text-gray-600 text-sm mb-4">How are you feeling right now?</p>
            <Button 
              onClick={() => setIsCheckInModalOpen(true)}
              className="w-full bg-primary-500 hover:bg-primary-600 text-white"
            >
              Log Mood
            </Button>
          </CardContent>
        </Card>

        {/* Craving Management Card */}
        <Card className="hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-accent-50 rounded-lg flex items-center justify-center">
                <Brain className="text-accent-500 w-6 h-6" />
              </div>
              <span className="text-sm text-gray-500">
                {latestMoodLog ? formatTimeAgo(new Date(latestMoodLog.timestamp)) : "No data"}
              </span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Coping Tools</h3>
            <p className="text-gray-600 text-sm mb-4">AI-powered strategies for you</p>
            <Button className="w-full bg-accent-500 hover:bg-accent-600 text-white">
              Get Help Now
            </Button>
          </CardContent>
        </Card>

        {/* Medication Reminder Card */}
        <Card className="hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-secondary-50 rounded-lg flex items-center justify-center">
                <Pill className="text-secondary-500 w-6 h-6" />
              </div>
              <span className="text-sm text-success-500 font-medium">On Track</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Medications</h3>
            <p className="text-gray-600 text-sm mb-4">Next dose in 3 hours</p>
            <Button className="w-full bg-secondary-500 hover:bg-secondary-600 text-white">
              View Schedule
            </Button>
          </CardContent>
        </Card>

        {/* Community Support Card */}
        <Card className="hover:shadow-md transition-shadow duration-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 bg-purple-50 rounded-lg flex items-center justify-center">
                <Users className="text-purple-500 w-6 h-6" />
              </div>
              <span className="text-sm text-green-500 font-medium">• Online</span>
            </div>
            <h3 className="text-lg font-semibold text-gray-900 mb-2">Community</h3>
            <p className="text-gray-600 text-sm mb-4">Connect with peers</p>
            <Button className="w-full bg-purple-500 hover:bg-purple-600 text-white">
              Join Chat
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Today's Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        {/* Daily Progress */}
        <div className="lg:col-span-2">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-semibold text-gray-900">Today's Progress</h3>
                <select className="text-sm text-gray-500 border border-gray-300 rounded-lg px-3 py-1">
                  <option>Today</option>
                  <option>This Week</option>
                  <option>This Month</option>
                </select>
              </div>
              
              {/* Progress Metrics */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary-600">{avgMood}</div>
                  <div className="text-sm text-gray-500">Avg Mood</div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div 
                      className="bg-primary-500 h-2 rounded-full" 
                      style={{ width: `${avgMood !== "N/A" ? (parseFloat(avgMood) / 10) * 100 : 0}%` }}
                    ></div>
                  </div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-success-600">{managedCravings}%</div>
                  <div className="text-sm text-gray-500">Cravings Managed</div>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div 
                      className="bg-success-500 h-2 rounded-full" 
                      style={{ width: `${managedCravings}%` }}
                    ></div>
                  </div>
                </div>
              </div>

              <ProgressChart />
            </CardContent>
          </Card>
        </div>

        {/* AI Insights & Alerts */}
        <Card>
          <CardContent className="p-6">
            <h3 className="text-xl font-semibold text-gray-900 mb-6">AI Insights</h3>
            
            {/* Current Alert */}
            <div className="bg-amber-50 border border-amber-200 rounded-lg p-4 mb-4">
              <div className="flex items-start gap-3">
                <Lightbulb className="text-amber-500 w-5 h-5 mt-1" />
                <div>
                  <h4 className="font-medium text-amber-800 mb-1">Pattern Detected</h4>
                  <p className="text-sm text-amber-700">
                    Your mood tends to dip around 3 PM. Consider scheduling a mindfulness break.
                  </p>
                </div>
              </div>
            </div>

            {/* Recommended Actions */}
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">Recommended for You</h4>
              
              <div className="flex items-center gap-3 p-3 bg-primary-50 rounded-lg border border-primary-100">
                <Leaf className="text-primary-500 w-5 h-5" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">5-Minute Breathing Exercise</p>
                  <p className="text-xs text-gray-600">Based on your current mood</p>
                </div>
                <Button size="sm" variant="ghost" className="text-primary-600 hover:text-primary-700">
                  Start
                </Button>
              </div>

              <div className="flex items-center gap-3 p-3 bg-secondary-50 rounded-lg border border-secondary-100">
                <Phone className="text-secondary-500 w-5 h-5" />
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-900">Call Support Buddy</p>
                  <p className="text-xs text-gray-600">Michael is available</p>
                </div>
                <Button size="sm" variant="ghost" className="text-secondary-600 hover:text-secondary-700">
                  Call
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Resources Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Educational Resources */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Learn & Grow</h3>
              <Button variant="ghost" className="text-primary-600 hover:text-primary-700 text-sm">
                View All
              </Button>
            </div>

            <div className="space-y-4">
              {featuredResources.map((resource) => (
                <div 
                  key={resource.id}
                  className="flex gap-4 p-4 bg-gray-50 rounded-lg border border-gray-200 hover:bg-gray-100 transition-colors duration-200 cursor-pointer"
                >
                  <div className="w-16 h-16 bg-gradient-to-br from-primary-100 to-primary-200 rounded-lg flex items-center justify-center flex-shrink-0">
                    {resource.type === "video" ? (
                      <div className="w-6 h-6 text-red-600">▶</div>
                    ) : (
                      <div className="w-6 h-6 text-primary-600">📖</div>
                    )}
                  </div>
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900 mb-1">{resource.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{resource.description}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <span>{resource.duration}</span>
                      <span>•</span>
                      <span className="capitalize">{resource.type}</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Professional Support */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">Professional Support</h3>
              <Button variant="ghost" className="text-primary-600 hover:text-primary-700 text-sm">
                Find More
              </Button>
            </div>

            <div className="space-y-4">
              {featuredProfessionals.map((professional, index) => {
                const bgColor = index === 0 ? "bg-green-50 border-green-200" : 
                                index === 1 ? "bg-blue-50 border-blue-200" : 
                                "bg-red-50 border-red-200";
                const iconColor = index === 0 ? "text-green-600" : 
                                 index === 1 ? "text-blue-600" : 
                                 "text-red-600";
                const buttonColor = index === 0 ? "bg-green-500 hover:bg-green-600" : 
                                   index === 1 ? "bg-blue-500 hover:bg-blue-600" : 
                                   "bg-red-500 hover:bg-red-600";

                return (
                  <div key={professional.id} className={`flex items-center gap-4 p-4 rounded-lg border ${bgColor}`}>
                    <div className={`w-12 h-12 bg-opacity-50 rounded-full flex items-center justify-center ${bgColor}`}>
                      {professional.type === "counselor" && <div className={`w-6 h-6 ${iconColor}`}>👨‍⚕️</div>}
                      {professional.type === "support_group" && <Users className={`w-6 h-6 ${iconColor}`} />}
                      {professional.type === "hotline" && <Phone className={`w-6 h-6 ${iconColor}`} />}
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{professional.name}</h4>
                      <p className="text-sm text-gray-600">
                        {professional.specialization} • {professional.availability}
                      </p>
                    </div>
                    <Button size="sm" className={`text-white ${buttonColor}`}>
                      {professional.type === "hotline" ? "Call" : professional.type === "support_group" ? "Join" : "Book"}
                    </Button>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Personalized Tips Section */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-primary-500" />
            Personalized Recovery Tips
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {personalizedTips.map((tip, index) => (
              <div key={index} className="p-4 bg-gradient-to-br from-primary-50 to-primary-100 rounded-lg border border-primary-200">
                <div className="flex items-start gap-3">
                  <div className="w-8 h-8 bg-primary-500 text-white rounded-full flex items-center justify-center text-sm font-semibold flex-shrink-0">
                    {index + 1}
                  </div>
                  <p className="text-sm text-gray-700">{tip}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <QuickCheckInModal 
        open={isCheckInModalOpen} 
        onOpenChange={setIsCheckInModalOpen} 
      />
    </div>
  );
}

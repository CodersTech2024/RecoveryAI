import { useState } from "react";
import { MessageCircle, Plus, Users, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { CommunityPost, CommunityReply } from "@shared/schema";
import { formatTimeAgo } from "@/lib/utils";

export default function Community() {
  const [isCreatePostOpen, setIsCreatePostOpen] = useState(false);
  const [newPostTitle, setNewPostTitle] = useState("");
  const [newPostContent, setNewPostContent] = useState("");
  const [isAnonymous, setIsAnonymous] = useState(true);
  const [selectedPostId, setSelectedPostId] = useState<number | null>(null);
  const [newReply, setNewReply] = useState("");

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: posts = [], isLoading } = useQuery<CommunityPost[]>({
    queryKey: ["/api/community/posts"],
  });

  const { data: replies = [] } = useQuery<CommunityReply[]>({
    queryKey: ["/api/community/posts", selectedPostId, "replies"],
    enabled: !!selectedPostId,
  });

  const createPostMutation = useMutation({
    mutationFn: (data: { title: string; content: string; isAnonymous: boolean }) =>
      apiRequest("POST", "/api/community/posts", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/posts"] });
      toast({
        title: "Post created",
        description: "Your post has been shared with the community.",
      });
      setNewPostTitle("");
      setNewPostContent("");
      setIsCreatePostOpen(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create post",
        variant: "destructive",
      });
    },
  });

  const createReplyMutation = useMutation({
    mutationFn: (data: { postId: number; content: string; isAnonymous: boolean }) =>
      apiRequest("POST", `/api/community/posts/${data.postId}/replies`, {
        content: data.content,
        isAnonymous: data.isAnonymous,
      }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/community/posts", selectedPostId, "replies"] });
      setNewReply("");
      toast({
        title: "Reply posted",
        description: "Your reply has been added to the discussion.",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to post reply",
        variant: "destructive",
      });
    },
  });

  const handleCreatePost = () => {
    if (!newPostTitle.trim() || !newPostContent.trim()) {
      toast({
        title: "Missing information",
        description: "Please fill in both title and content",
        variant: "destructive",
      });
      return;
    }

    createPostMutation.mutate({
      title: newPostTitle,
      content: newPostContent,
      isAnonymous,
    });
  };

  const handleCreateReply = () => {
    if (!newReply.trim() || !selectedPostId) {
      toast({
        title: "Missing information",
        description: "Please enter a reply",
        variant: "destructive",
      });
      return;
    }

    createReplyMutation.mutate({
      postId: selectedPostId,
      content: newReply,
      isAnonymous: true,
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Community Support</h1>
            <p className="text-gray-600">Connect with others on their recovery journey. Share experiences and support each other.</p>
          </div>
          <Dialog open={isCreatePostOpen} onOpenChange={setIsCreatePostOpen}>
            <DialogTrigger asChild>
              <Button className="bg-primary-500 hover:bg-primary-600 text-white">
                <Plus className="w-4 h-4 mr-2" />
                New Post
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-2xl">
              <DialogHeader>
                <DialogTitle>Share with the Community</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    value={newPostTitle}
                    onChange={(e) => setNewPostTitle(e.target.value)}
                    placeholder="What would you like to share?"
                  />
                </div>
                <div>
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    value={newPostContent}
                    onChange={(e) => setNewPostContent(e.target.value)}
                    placeholder="Share your thoughts, experiences, or ask for support..."
                    rows={6}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="anonymous"
                    checked={isAnonymous}
                    onCheckedChange={setIsAnonymous}
                  />
                  <Label htmlFor="anonymous" className="text-sm">
                    Post anonymously (recommended)
                  </Label>
                </div>
                <div className="flex gap-3 pt-4">
                  <Button
                    variant="outline"
                    onClick={() => setIsCreatePostOpen(false)}
                    disabled={createPostMutation.isPending}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={handleCreatePost}
                    disabled={createPostMutation.isPending}
                    className="bg-primary-500 hover:bg-primary-600"
                  >
                    {createPostMutation.isPending ? "Posting..." : "Share Post"}
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Community Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Members</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">247</div>
            <p className="text-xs text-muted-foreground">Online now</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Posts</CardTitle>
            <MessageCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{posts.length}</div>
            <p className="text-xs text-muted-foreground">Community discussions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Support Given</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">1.2k</div>
            <p className="text-xs text-muted-foreground">Replies this week</p>
          </CardContent>
        </Card>
      </div>

      {/* Posts List */}
      <div className="space-y-6">
        {posts.length === 0 ? (
          <Card>
            <CardContent className="text-center py-12">
              <div className="text-gray-400 text-4xl mb-4">💬</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No posts yet</h3>
              <p className="text-gray-600 mb-4">Be the first to share something with the community</p>
              <Button 
                onClick={() => setIsCreatePostOpen(true)}
                className="bg-primary-500 hover:bg-primary-600 text-white"
              >
                Create First Post
              </Button>
            </CardContent>
          </Card>
        ) : (
          posts.map((post) => (
            <Card key={post.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                      <Users className="w-5 h-5 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{post.isAnonymous ? "Anonymous" : "User"}</h3>
                      <p className="text-sm text-gray-500">{formatTimeAgo(new Date(post.timestamp))}</p>
                    </div>
                  </div>
                </div>
                
                <h2 className="text-xl font-semibold text-gray-900 mb-3">{post.title}</h2>
                <p className="text-gray-700 mb-4 leading-relaxed">{post.content}</p>
                
                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <Button
                    variant="ghost"
                    onClick={() => setSelectedPostId(post.id)}
                    className="text-primary-600 hover:text-primary-700"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    View Discussion
                  </Button>
                  <span className="text-sm text-gray-500">
                    {/* In a real app, this would show the actual reply count */}
                    0 replies
                  </span>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Post Detail Dialog */}
      <Dialog open={!!selectedPostId} onOpenChange={() => setSelectedPostId(null)}>
        <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
          {selectedPostId && (
            <>
              <DialogHeader>
                <DialogTitle>Discussion</DialogTitle>
              </DialogHeader>
              
              {(() => {
                const post = posts.find(p => p.id === selectedPostId);
                if (!post) return null;
                
                return (
                  <div className="space-y-6">
                    {/* Original Post */}
                    <div className="border-b border-gray-200 pb-6">
                      <div className="flex items-center gap-3 mb-4">
                        <div className="w-10 h-10 bg-primary-100 rounded-full flex items-center justify-center">
                          <Users className="w-5 h-5 text-primary-600" />
                        </div>
                        <div>
                          <h3 className="font-medium text-gray-900">{post.isAnonymous ? "Anonymous" : "User"}</h3>
                          <p className="text-sm text-gray-500">{formatTimeAgo(new Date(post.timestamp))}</p>
                        </div>
                      </div>
                      <h2 className="text-xl font-semibold text-gray-900 mb-3">{post.title}</h2>
                      <p className="text-gray-700 leading-relaxed">{post.content}</p>
                    </div>

                    {/* Replies */}
                    <div className="space-y-4">
                      {replies.map((reply) => (
                        <div key={reply.id} className="flex items-start gap-3 p-4 bg-gray-50 rounded-lg">
                          <div className="w-8 h-8 bg-secondary-100 rounded-full flex items-center justify-center">
                            <Users className="w-4 h-4 text-secondary-600" />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <span className="font-medium text-gray-900">
                                {reply.isAnonymous ? "Anonymous" : "User"}
                              </span>
                              <span className="text-sm text-gray-500">
                                {formatTimeAgo(new Date(reply.timestamp))}
                              </span>
                            </div>
                            <p className="text-gray-700">{reply.content}</p>
                          </div>
                        </div>
                      ))}
                      
                      {replies.length === 0 && (
                        <p className="text-center text-gray-500 py-8">
                          No replies yet. Be the first to respond!
                        </p>
                      )}
                    </div>

                    {/* Reply Form */}
                    <div className="border-t border-gray-200 pt-6">
                      <div className="space-y-3">
                        <Label htmlFor="reply">Add your reply</Label>
                        <Textarea
                          id="reply"
                          value={newReply}
                          onChange={(e) => setNewReply(e.target.value)}
                          placeholder="Share your thoughts or offer support..."
                          rows={3}
                        />
                        <div className="flex justify-end">
                          <Button
                            onClick={handleCreateReply}
                            disabled={createReplyMutation.isPending}
                            className="bg-primary-500 hover:bg-primary-600"
                          >
                            {createReplyMutation.isPending ? "Posting..." : "Post Reply"}
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })()}
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

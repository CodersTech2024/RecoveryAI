import { useState } from "react";
import { User, Calendar, Trophy, Settings, Phone, Bell } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { User as UserType, MoodLog } from "@shared/schema";

export default function Profile() {
  const [isEditing, setIsEditing] = useState(false);
  const [daysSober, setDaysSober] = useState("");
  const [emergencyContact, setEmergencyContact] = useState("");
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: user } = useQuery<UserType>({
    queryKey: ["/api/user"],
  });

  const { data: moodLogs = [] } = useQuery<MoodLog[]>({
    queryKey: ["/api/mood-logs"],
  });

  const updateUserMutation = useMutation({
    mutationFn: (data: { daysSober: number }) =>
      apiRequest("PATCH", "/api/user/days-sober", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({
        title: "Profile updated",
        description: "Your profile has been successfully updated.",
      });
      setIsEditing(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update profile",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const days = parseInt(daysSober);
    if (isNaN(days) || days < 0) {
      toast({
        title: "Invalid input",
        description: "Please enter a valid number of days",
        variant: "destructive",
      });
      return;
    }

    updateUserMutation.mutate({ daysSober: days });
  };

  const totalCheckIns = moodLogs.length;
  const avgMood = moodLogs.length > 0 
    ? (moodLogs.reduce((sum, log) => sum + log.mood, 0) / moodLogs.length).toFixed(1)
    : "0";

  const streakDays = user?.daysSober || 0;
  const milestones = [
    { days: 1, title: "First Day", achieved: streakDays >= 1 },
    { days: 7, title: "One Week", achieved: streakDays >= 7 },
    { days: 30, title: "One Month", achieved: streakDays >= 30 },
    { days: 90, title: "Three Months", achieved: streakDays >= 90 },
    { days: 365, title: "One Year", achieved: streakDays >= 365 },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Profile & Settings</h1>
        <p className="text-gray-600">Manage your account, track your progress, and customize your experience.</p>
      </div>

      {/* Profile Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="lg:col-span-2">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-primary-600" />
                </div>
                Profile Information
              </CardTitle>
              <Button
                variant="outline"
                onClick={() => {
                  if (isEditing) {
                    setIsEditing(false);
                  } else {
                    setDaysSober(user?.daysSober?.toString() || "0");
                    setIsEditing(true);
                  }
                }}
              >
                {isEditing ? "Cancel" : "Edit"}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="username">Username</Label>
              <Input
                id="username"
                value={user?.username || ""}
                disabled
                className="bg-gray-50"
              />
            </div>
            
            <div>
              <Label htmlFor="daysSober">Days Sober</Label>
              {isEditing ? (
                <Input
                  id="daysSober"
                  type="number"
                  value={daysSober}
                  onChange={(e) => setDaysSober(e.target.value)}
                  min="0"
                />
              ) : (
                <Input
                  id="daysSober"
                  value={user?.daysSober || 0}
                  disabled
                  className="bg-gray-50"
                />
              )}
            </div>

            <div>
              <Label htmlFor="emergencyContact">Emergency Contact</Label>
              <Input
                id="emergencyContact"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="Phone number or contact info"
                disabled={!isEditing}
                className={!isEditing ? "bg-gray-50" : ""}
              />
            </div>

            {isEditing && (
              <div className="flex gap-3 pt-4">
                <Button
                  onClick={handleSave}
                  disabled={updateUserMutation.isPending}
                  className="bg-primary-500 hover:bg-primary-600"
                >
                  {updateUserMutation.isPending ? "Saving..." : "Save Changes"}
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Stats Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Recovery Stats</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary-600">{streakDays}</div>
              <div className="text-sm text-gray-500">Days Sober</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-secondary-600">{totalCheckIns}</div>
              <div className="text-sm text-gray-500">Check-ins</div>
            </div>
            
            <div className="text-center">
              <div className="text-2xl font-bold text-accent-600">{avgMood}/10</div>
              <div className="text-sm text-gray-500">Avg Mood</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Milestones */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trophy className="w-5 h-5 text-yellow-500" />
            Recovery Milestones
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {milestones.map((milestone) => (
              <div
                key={milestone.days}
                className={`text-center p-4 rounded-lg border ${
                  milestone.achieved
                    ? "bg-primary-50 border-primary-200"
                    : "bg-gray-50 border-gray-200"
                }`}
              >
                <div className={`text-2xl mb-2 ${milestone.achieved ? "text-primary-600" : "text-gray-400"}`}>
                  {milestone.achieved ? "🏆" : "⏳"}
                </div>
                <div className={`font-medium ${milestone.achieved ? "text-primary-700" : "text-gray-500"}`}>
                  {milestone.title}
                </div>
                <div className="text-sm text-gray-500">{milestone.days} days</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Settings */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            App Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-gray-500" />
              <div>
                <div className="font-medium">Push Notifications</div>
                <div className="text-sm text-gray-500">Receive reminders and check-in notifications</div>
              </div>
            </div>
            <Switch
              checked={notificationsEnabled}
              onCheckedChange={setNotificationsEnabled}
            />
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-gray-500" />
              <div>
                <div className="font-medium">Emergency Contacts</div>
                <div className="text-sm text-gray-500">Manage who to contact in emergencies</div>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Manage
            </Button>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Calendar className="w-5 h-5 text-gray-500" />
              <div>
                <div className="font-medium">Reminder Schedule</div>
                <div className="text-sm text-gray-500">Set up check-in and medication reminders</div>
              </div>
            </div>
            <Button variant="outline" size="sm">
              Configure
            </Button>
          </div>

          <div className="pt-6 border-t border-gray-200">
            <div className="space-y-3">
              <h4 className="font-medium text-gray-900">Data & Privacy</h4>
              <p className="text-sm text-gray-600">
                Your data is stored securely and privately. We never share your personal information 
                with third parties without your explicit consent.
              </p>
              <div className="flex gap-3">
                <Button variant="outline" size="sm">
                  Privacy Policy
                </Button>
                <Button variant="outline" size="sm">
                  Export Data
                </Button>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

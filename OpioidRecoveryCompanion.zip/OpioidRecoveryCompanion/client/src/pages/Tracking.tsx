import { useState } from "react";
import { Calendar, TrendingUp, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import QuickCheckInModal from "@/components/QuickCheckInModal";
import ProgressChart from "@/components/ProgressChart";
import type { MoodLog } from "@shared/schema";
import { getMoodColor, getCravingColor, formatTimeAgo } from "@/lib/utils";

export default function Tracking() {
  const [isCheckInModalOpen, setIsCheckInModalOpen] = useState(false);

  const { data: moodLogs = [], isLoading } = useQuery<MoodLog[]>({
    queryKey: ["/api/mood-logs"],
  });

  if (isLoading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="flex items-center justify-center h-64">
          <div className="animate-spin w-8 h-8 border-2 border-primary-500 border-t-transparent rounded-full"></div>
        </div>
      </div>
    );
  }

  const avgMood = moodLogs.length > 0 
    ? (moodLogs.reduce((sum, log) => sum + log.mood, 0) / moodLogs.length).toFixed(1)
    : "0";

  const managedCravings = moodLogs.length > 0
    ? Math.round((moodLogs.filter(log => log.cravingLevel === "none" || log.cravingLevel === "mild").length / moodLogs.length) * 100)
    : 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Mood & Craving Tracking</h1>
        <p className="text-gray-600">Monitor your progress and identify patterns in your recovery journey.</p>
      </div>

      {/* Quick Actions */}
      <div className="mb-8">
        <Button 
          onClick={() => setIsCheckInModalOpen(true)}
          className="bg-primary-500 hover:bg-primary-600 text-white"
        >
          Add New Check-in
        </Button>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Check-ins</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{moodLogs.length}</div>
            <p className="text-xs text-muted-foreground">Logged entries</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Average Mood</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{avgMood}/10</div>
            <p className="text-xs text-muted-foreground">
              {parseFloat(avgMood) >= 7 ? "Great!" : parseFloat(avgMood) >= 5 ? "Good" : "Needs attention"}
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Cravings Managed</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{managedCravings}%</div>
            <p className="text-xs text-muted-foreground">None to mild cravings</p>
          </CardContent>
        </Card>
      </div>

      {/* Progress Chart */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Mood & Craving Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ProgressChart />
        </CardContent>
      </Card>

      {/* Recent Entries */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Check-ins</CardTitle>
        </CardHeader>
        <CardContent>
          {moodLogs.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 text-4xl mb-4">📊</div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No check-ins yet</h3>
              <p className="text-gray-600 mb-4">Start tracking your mood and cravings to see your progress</p>
              <Button 
                onClick={() => setIsCheckInModalOpen(true)}
                className="bg-primary-500 hover:bg-primary-600 text-white"
              >
                Add Your First Check-in
              </Button>
            </div>
          ) : (
            <div className="space-y-4">
              {moodLogs.slice(0, 10).map((log) => (
                <div key={log.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-4">
                    <div className="text-center">
                      <div className={`text-lg font-bold ${getMoodColor(log.mood)}`}>
                        {log.mood}/10
                      </div>
                      <div className="text-xs text-gray-500">Mood</div>
                    </div>
                    <div className="text-center">
                      <div className={`text-sm font-medium capitalize ${getCravingColor(log.cravingLevel)}`}>
                        {log.cravingLevel}
                      </div>
                      <div className="text-xs text-gray-500">Craving</div>
                    </div>
                    {log.notes && (
                      <div className="max-w-xs">
                        <p className="text-sm text-gray-700 truncate">{log.notes}</p>
                      </div>
                    )}
                  </div>
                  <div className="text-sm text-gray-500">
                    {formatTimeAgo(new Date(log.timestamp))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <QuickCheckInModal 
        open={isCheckInModalOpen} 
        onOpenChange={setIsCheckInModalOpen} 
      />
    </div>
  );
}

import { useMemo } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { useQuery } from "@tanstack/react-query";
import type { MoodLog } from "@shared/schema";
import { formatTimeAgo } from "@/lib/utils";

export default function ProgressChart() {
  const { data: moodLogs = [], isLoading } = useQuery<MoodLog[]>({
    queryKey: ["/api/mood-logs"],
  });

  const chartData = useMemo(() => {
    return moodLogs
      .slice(-7) // Last 7 entries
      .map((log, index) => ({
        name: `Day ${index + 1}`,
        mood: log.mood,
        craving: log.cravingLevel === "none" ? 0 : 
                log.cravingLevel === "mild" ? 3 :
                log.cravingLevel === "moderate" ? 6 :
                log.cravingLevel === "strong" ? 9 : 0,
        date: new Date(log.timestamp).toLocaleDateString(),
      }));
  }, [moodLogs]);

  if (isLoading) {
    return (
      <div className="bg-gray-50 rounded-lg p-4 h-48 flex items-center justify-center border border-gray-200">
        <div className="text-center text-gray-500">
          <div className="animate-spin w-6 h-6 border-2 border-primary-500 border-t-transparent rounded-full mx-auto mb-2"></div>
          <p className="text-sm">Loading chart...</p>
        </div>
      </div>
    );
  }

  if (chartData.length === 0) {
    return (
      <div className="bg-gray-50 rounded-lg p-4 h-48 flex items-center justify-center border border-gray-200">
        <div className="text-center text-gray-500">
          <div className="text-3xl mb-2">📈</div>
          <p className="text-sm">No mood data yet</p>
          <p className="text-xs">Complete your first check-in to see trends</p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-50 rounded-lg p-4 h-48 border border-gray-200">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
          <XAxis 
            dataKey="name" 
            tick={{ fontSize: 12 }}
            stroke="#6b7280"
          />
          <YAxis 
            domain={[0, 10]}
            tick={{ fontSize: 12 }}
            stroke="#6b7280"
          />
          <Tooltip 
            contentStyle={{
              backgroundColor: 'white',
              border: '1px solid #e5e7eb',
              borderRadius: '8px',
              fontSize: '12px'
            }}
            formatter={(value: number, name: string) => [
              name === 'mood' ? `${value}/10` : 
              value === 0 ? 'None' :
              value <= 3 ? 'Mild' :
              value <= 6 ? 'Moderate' : 'Strong',
              name === 'mood' ? 'Mood' : 'Craving'
            ]}
          />
          <Line 
            type="monotone" 
            dataKey="mood" 
            stroke="hsl(123, 38%, 32%)" 
            strokeWidth={2}
            dot={{ fill: "hsl(123, 38%, 32%)", strokeWidth: 2, r: 4 }}
          />
          <Line 
            type="monotone" 
            dataKey="craving" 
            stroke="hsl(36, 77%, 68%)" 
            strokeWidth={2}
            dot={{ fill: "hsl(36, 77%, 68%)", strokeWidth: 2, r: 4 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}

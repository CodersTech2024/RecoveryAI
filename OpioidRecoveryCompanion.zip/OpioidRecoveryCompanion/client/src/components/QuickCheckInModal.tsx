import { useState } from "react";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface QuickCheckInModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export default function QuickCheckInModal({ open, onOpenChange }: QuickCheckInModalProps) {
  const [selectedMood, setSelectedMood] = useState<number | null>(null);
  const [selectedCraving, setSelectedCraving] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const createMoodLogMutation = useMutation({
    mutationFn: (data: { mood: number; cravingLevel: string; notes?: string }) =>
      apiRequest("POST", "/api/mood-logs", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/mood-logs"] });
      toast({
        title: "Check-in saved",
        description: "Your mood and craving data has been recorded.",
      });
      handleClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to save check-in",
        variant: "destructive",
      });
    },
  });

  const handleClose = () => {
    setSelectedMood(null);
    setSelectedCraving(null);
    setNotes("");
    onOpenChange(false);
  };

  const handleSave = () => {
    if (selectedMood === null || selectedCraving === null) {
      toast({
        title: "Missing information",
        description: "Please select both mood and craving level",
        variant: "destructive",
      });
      return;
    }

    createMoodLogMutation.mutate({
      mood: selectedMood,
      cravingLevel: selectedCraving,
      notes: notes.trim() || undefined,
    });
  };

  const moodNumbers = Array.from({ length: 10 }, (_, i) => i + 1);
  const cravingLevels = [
    { value: "none", label: "None" },
    { value: "mild", label: "Mild" },
    { value: "moderate", label: "Moderate" },
    { value: "strong", label: "Strong" },
  ];

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold text-gray-900">
            Quick Check-in
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Mood Rating */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-3 block">
              How are you feeling right now?
            </Label>
            <div className="flex justify-between items-center gap-2">
              {moodNumbers.map((mood) => (
                <Button
                  key={mood}
                  variant="outline"
                  size="sm"
                  onClick={() => setSelectedMood(mood)}
                  className={cn(
                    "w-10 h-10 rounded-full border-2 transition-colors",
                    selectedMood === mood
                      ? "bg-primary-500 text-white border-primary-500"
                      : "border-gray-300 hover:border-primary-500"
                  )}
                >
                  {mood}
                </Button>
              ))}
            </div>
            <div className="flex justify-between text-xs text-gray-500 mt-2">
              <span>Very Low</span>
              <span>Excellent</span>
            </div>
          </div>

          {/* Craving Level */}
          <div>
            <Label className="text-sm font-medium text-gray-700 mb-3 block">
              Any cravings right now?
            </Label>
            <div className="grid grid-cols-2 gap-2">
              {cravingLevels.map((craving) => (
                <Button
                  key={craving.value}
                  variant="outline"
                  onClick={() => setSelectedCraving(craving.value)}
                  className={cn(
                    "p-3 border transition-colors",
                    selectedCraving === craving.value
                      ? "bg-primary-500 text-white border-primary-500"
                      : "border-gray-300 hover:bg-gray-50"
                  )}
                >
                  {craving.label}
                </Button>
              ))}
            </div>
          </div>

          {/* Optional Notes */}
          <div>
            <Label htmlFor="notes" className="text-sm font-medium text-gray-700 mb-2 block">
              Notes (optional)
            </Label>
            <Textarea
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Anything you'd like to add about how you're feeling..."
              rows={3}
              className="resize-none"
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3">
            <Button
              variant="outline"
              onClick={handleClose}
              className="flex-1"
              disabled={createMoodLogMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              className="flex-1 bg-primary-500 hover:bg-primary-600"
              disabled={createMoodLogMutation.isPending}
            >
              {createMoodLogMutation.isPending ? "Saving..." : "Save Check-in"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

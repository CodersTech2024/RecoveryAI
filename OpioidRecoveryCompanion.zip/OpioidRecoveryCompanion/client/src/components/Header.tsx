import { AlertTriangle, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";

export default function Header() {
  const { toast } = useToast();
  const [showSOSDialog, setShowSOSDialog] = useState(false);

  const handleEmergencySOS = () => {
    setShowSOSDialog(true);
  };

  const handleCallEmergency = () => {
    const confirmed = window.confirm(
      "Are you sure you want to call emergency services (911)? This should only be used for life-threatening emergencies."
    );
    if (confirmed) {
      window.open("tel:911", "_self");
      setShowSOSDialog(false);
      toast({
        title: "Emergency Call Initiated",
        description: "Calling emergency services now.",
        variant: "destructive",
      });
    }
  };

  const handleCallCrisisHotline = () => {
    const confirmed = window.confirm(
      "Are you sure you want to call the crisis hotline (988)? They provide 24/7 mental health support."
    );
    if (confirmed) {
      window.open("tel:988", "_self");
      setShowSOSDialog(false);
      toast({
        title: "Crisis Hotline Called",
        description: "Connecting to crisis support.",
      });
    }
  };

  const handleCallRehabClinic = () => {
    const choice = window.confirm(
      "Would you like to call the Rehab Clinics Group?\n\nClick OK for Freephone (0800 470 0382)\nClick Cancel for Local (03301 596 494)"
    );
    
    const number = choice ? "08004700382" : "03301596494";
    const numberDisplay = choice ? "0800 470 0382" : "03301 596 494";
    
    const confirmed = window.confirm(
      `Are you sure you want to call Rehab Clinics Group at ${numberDisplay}?`
    );
    
    if (confirmed) {
      window.open(`tel:${number}`, "_self");
      setShowSOSDialog(false);
      toast({
        title: "Calling Rehab Clinics Group",
        description: `Connecting to ${numberDisplay}`,
      });
    }
  };

  const handleSendLocationSMS = () => {
    // In a real app, this would send GPS location to emergency contacts
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          const locationMessage = `EMERGENCY: I need help. My location: https://maps.google.com/?q=${lat},${lng}`;
          
          // This would normally send SMS to emergency contacts
          toast({
            title: "Location Shared",
            description: "Emergency contacts have been notified with your location.",
            variant: "destructive",
          });
        },
        () => {
          toast({
            title: "Location Unavailable",
            description: "Could not access location. Please call for help.",
            variant: "destructive",
          });
        }
      );
    }
    setShowSOSDialog(false);
  };

  return (
    <>
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-xl font-bold text-primary-600">RecoveryAI</h1>
              </div>
            </div>
            
            <Button 
              onClick={handleEmergencySOS}
              className="bg-error-500 hover:bg-error-600 text-white px-4 py-2 rounded-full font-medium flex items-center gap-2 transition-colors duration-200"
            >
              <AlertTriangle className="w-4 h-4" />
              <span className="hidden sm:inline">SOS</span>
            </Button>
          </div>
        </div>
      </header>

      <Dialog open={showSOSDialog} onOpenChange={setShowSOSDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-red-600 flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Emergency Support
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-gray-700 text-sm">
              Choose the type of help you need right now:
            </p>
            
            <div className="space-y-3">
              <Button
                onClick={handleCallEmergency}
                className="w-full bg-red-600 hover:bg-red-700 text-white justify-start gap-3 h-12"
              >
                <Phone className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-medium">Call 911</div>
                  <div className="text-sm opacity-90">Medical emergency</div>
                </div>
              </Button>
              
              <Button
                onClick={handleCallCrisisHotline}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white justify-start gap-3 h-12"
              >
                <Phone className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-medium">Crisis Hotline (988)</div>
                  <div className="text-sm opacity-90">Mental health crisis</div>
                </div>
              </Button>
              
              <Button
                onClick={handleCallRehabClinic}
                className="w-full bg-green-600 hover:bg-green-700 text-white justify-start gap-3 h-12"
              >
                <Phone className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-medium">Rehab Clinics Group</div>
                  <div className="text-sm opacity-90">Professional addiction support</div>
                </div>
              </Button>
              
              <Button
                onClick={handleSendLocationSMS}
                className="w-full bg-orange-600 hover:bg-orange-700 text-white justify-start gap-3 h-12"
              >
                <AlertTriangle className="w-5 h-5" />
                <div className="text-left">
                  <div className="font-medium">Share Location</div>
                  <div className="text-sm opacity-90">Alert emergency contacts</div>
                </div>
              </Button>
            </div>
            
            <div className="pt-4 border-t">
              <Button
                variant="outline"
                onClick={() => setShowSOSDialog(false)}
                className="w-full"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
